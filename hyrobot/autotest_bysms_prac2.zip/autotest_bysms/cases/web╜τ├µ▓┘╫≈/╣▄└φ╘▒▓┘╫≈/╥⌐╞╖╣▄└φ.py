from hyrobot.common import *
from lib.webui import *
from time import sleep



class c0105:
    name = '药品管理 - UI-0105'

    # 测试用例步骤
    def teststeps(self):

        wd = get_global_webdriver()


        STEP(1, '点击左侧客户菜单')
        clickMenu(wd,'药品')



        STEP(2, '添加药品')

        # 点击添加药品按钮
        wd.find_element_by_class_name('glyphicon-plus').click()

        # form-contorl 对应3个输入框
        inputs = wd.find_elements_by_css_selector('.add-one-area .form-control')

        # 输入 药品名称
        inputs[0].send_keys('青霉素盒装1')
        # 输入 编号
        inputs[1].send_keys('YP-32342349')
        # 输入 描述
        inputs[2].send_keys('青霉素注射液，每支15ml，20支装')

        # 第1个 btn-xs 就是创建按钮， 点击创建按钮
        wd.find_element_by_css_selector('.add-one-area .btn-xs').click()

        # 等待1秒
        sleep(1)



        STEP(3, '检查添加药品')
        # 找到 列表最上面的药品信息
        items = wd.find_elements_by_css_selector(
            'div.search-result-item span')[:6]

        texts = [item.text for item in items]
        print(texts)

        # 预期内容为
        expected = [
            '药品：',
            '青霉素盒装1',
            '编号：',
            'YP-32342349',
            '描述：',
            '青霉素注射液，每支15ml，20支装'
        ]

        CHECK_POINT('药品信息和添加内容一致', texts == expected)