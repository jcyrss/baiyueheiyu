from hyrobot.common import *
from lib.webui import  *

def suite_setup():
    mgr_login(get_global_webdriver())

