from hyrobot.common import *
from lib.webui import  *

def suite_setup():
    wd = open_browser()

def suite_teardown():
    INFO('关闭浏览器')
    wd = get_global_webdriver()
    wd.quit()