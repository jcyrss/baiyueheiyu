from selenium import webdriver
from hyrobot.common import *

def open_browser():

    print('打开浏览器')
    wd = webdriver.Chrome()
    wd.implicitly_wait(5)

    # 使用黑羽robot 全局存储对象 GSTORE
    GSTORE['global_webdriver'] = wd
    return wd

# 获取 全局使用的 webdriver 对象
def get_global_webdriver():
    return GSTORE['global_webdriver']


def mgr_login(wd):

    INFO('管理员登陆')

    wd.get('http://127.0.0.1/mgr/sign.html')

    # 根据 ID 选择元素，并且输入字符串
    wd.find_element_by_id('username').send_keys('byhy')
    wd.find_element_by_id('password').send_keys('88888888')

    # 根据标签名查找元素
    wd.find_element_by_tag_name('button').click()

def clickMenu(wd,menuName):
    if menuName == '客户':
        # 找到所有的菜单
        menus = wd.find_elements_by_css_selector('.sidebar-menu span')

        # 第一个span对应的菜单是 客户，点击它
        menus[0].click()


    if menuName == '药品':
        # 找到所有的菜单
        menus = wd.find_elements_by_css_selector('.sidebar-menu span')

        # 第2个span对应的菜单是 药品，点击它
        menus[1].click()