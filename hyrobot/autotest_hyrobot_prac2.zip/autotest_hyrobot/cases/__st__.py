force_tags = ['冒烟测试','订单功能']

def suite_setup():
    pass

def suite_teardown():
    pass


def test_setup():
    pass

def test_teardown():
    pass