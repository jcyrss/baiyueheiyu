from lib.webui import *

def suite_setup():
    wd = webdriver.Chrome()
    wd.implicitly_wait(5)

    mgr_login(wd)

    # 点击订单菜单，删除所有订单
    wd.find_element_by_css_selector('.sidebar-menu li:nth-of-type(4)').click()
    delAll(wd)

    # 点击药品菜单，删除所有药品
    wd.find_element_by_css_selector('.sidebar-menu li:nth-of-type(3)').click()
    delAll(wd)

    # 点击客户菜单，删除所有客户
    wd.find_element_by_css_selector('.sidebar-menu li:nth-of-type(2)').click()
    delAll(wd)
    wd.quit()
