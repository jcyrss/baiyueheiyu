from hyrobot.common import *
from lib.webui import *
# 导入Select类
from selenium.webdriver.support.ui import Select


class c0108:
    name = '订单管理 - UI-0108'

    # 测试用例步骤
    def teststeps(self):
        wd = get_global_webdriver()

        # ****  第1步：添加 客户 、 药品 、订单

        STEP(1, '添加 客户 、 药品 、订单')

        # ****   添加 客户 和 药品 *****

        # 点击药品菜单
        wd.find_element_by_css_selector('.sidebar-menu li:nth-of-type(2)').click()

        addCustomerOrMedicion(wd,'南京中医院1', '2551867851', '江苏省-南京市-秦淮区-汉中路-501')
        addCustomerOrMedicion(wd,'南京中医院2', '2551867852', '江苏省-南京市-秦淮区-汉中路-502')
        addCustomerOrMedicion(wd,'南京中医院3', '2551867853', '江苏省-南京市-秦淮区-汉中路-503')

        # 点击客户菜单
        wd.find_element_by_css_selector('.sidebar-menu li:nth-of-type(3)').click()
        addCustomerOrMedicion(wd,'青霉素盒装1', 'YP-32342341', '青霉素注射液，每支15ml，20支装')
        addCustomerOrMedicion(wd,'青霉素盒装2', 'YP-32342342', '青霉素注射液，每支15ml，30支装')
        addCustomerOrMedicion(wd,'青霉素盒装3', 'YP-32342343', '青霉素注射液，每支15ml，40支装')

        # ****   添加 订单 *****

        # 点击订单菜单
        wd.find_element_by_css_selector('.sidebar-menu li:nth-of-type(4)').click()

        # 点击添加按钮
        wd.find_element_by_class_name('glyphicon-plus').click()

        # 输入订单名称
        name = wd.find_element_by_css_selector('.add-one-area .form-control')
        name.send_keys('南中订单1')

        # 两个select
        selectElements = wd.find_elements_by_css_selector('.add-one-area select')

        # 选择客户
        Select(selectElements[0]).select_by_visible_text("南京中医院2")
        # 选择药品
        Select(selectElements[1]).select_by_visible_text("青霉素盒装1")

        wd.find_element_by_css_selector(
            '.add-one-area input[type=number]') \
            .send_keys('100')

        # 第1个 btn-xs 就是创建按钮， 点击创建按钮
        wd.find_element_by_css_selector('.add-one-area .btn-xs').click()



        STEP(2, '检查订单')

        # 找到 列表最上面的药品信息
        # 注意，药品
        items = wd.find_elements_by_css_selector(
            'div.search-result-item span,div.search-result-item p')[:8]

        texts = [item.text for item in items]
        print(texts)

        # 订单日期信息到秒，不方便直接验证，先取出来
        orderTime = texts.pop(3)

        # 预期内容为
        expected = [
            '订单：',
            '南中订单1',
            '日期：',
            '客户：',
            '南京中医院2',
            '药品：',
            '青霉素盒装1 * 100'
        ]

        CHECK_POINT('药品信息和添加内容一致', texts == expected)

        # 再检查订单日期时间，转化为整数时间，好比较
        intOrderTime = int(time.mktime(time.strptime(orderTime, '%Y-%m-%d %H:%M:%S')))
        curTime = int(time.time())
        # 绝对值 差距在100秒内
        deviation = abs(intOrderTime - curTime)
        print(deviation)
        CHECK_POINT('订单时间误差', deviation < 100)