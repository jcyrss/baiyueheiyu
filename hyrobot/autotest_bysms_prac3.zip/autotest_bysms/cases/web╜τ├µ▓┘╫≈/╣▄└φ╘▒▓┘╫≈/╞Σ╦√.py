from hyrobot.common import *
from lib.webui import *
from time import sleep



class c0106:
    name = '其他 - UI-0106'

    #清除方法
    def teardown(self):
        mgr_login(get_global_webdriver())

    # 测试用例步骤
    def teststeps(self):

        wd = get_global_webdriver()


        STEP(1, '点击页面右下角链接')

        # 根据标签名查找元素
        wd.find_element_by_tag_name('button').click()

        wd.find_element_by_css_selector('.main-footer .pull-right').click()

        # 记录当前窗口 handler，一遍后续返回
        startWnd = wd.current_window_handle

        # 切换到打开的 白月黑羽网页
        for wnd in wd.window_handles:
            wd.switch_to.window(wnd)
            if '白月黑羽' in wd.title:
                wd.maximize_window()
                break



        STEP(2, '检查导航菜单项目')
        navItems = wd.find_elements_by_css_selector('#site-nav li')
        navTitles = [item.text for item in navItems]
        print(navTitles)

        CHECK_POINT('白月黑羽官网菜单是否和预期一致',
                     navTitles == [
                         'Python基础',
                         'Python进阶',
                         'Web开发',
                         '自动化和性能测试',
                         'Linux和MySQL',
                         '练习作业',
                         '常见问题',
                         '好文分享'
                     ])


        STEP(3, '退出登录')
        wd.switch_to.window(startWnd)

        # 点击顶部 用户 图标
        wd.find_element_by_css_selector('.navbar-custom-menu .user-menu').click()

        # 点击退出登录
        wd.find_element_by_css_selector('.user-footer div.pull-right').click()

        # 等待一会儿，等待新的网址加载
        from time import sleep
        sleep(2)

        # 检查url，判断是否进入登录页面
        CHECK_POINT('进入登录页面', '/mgr/sign.html' in wd.current_url)