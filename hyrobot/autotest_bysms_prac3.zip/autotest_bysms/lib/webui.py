from selenium import webdriver
from hyrobot.common import *
import time

def open_browser():

    print('打开浏览器')
    wd = webdriver.Chrome()
    wd.implicitly_wait(5)

    # 使用黑羽robot 全局存储对象 GSTORE
    GSTORE['global_webdriver'] = wd
    return wd

# 获取 全局使用的 webdriver 对象
def get_global_webdriver():
    return GSTORE['global_webdriver']


def mgr_login(wd):

    INFO('管理员登陆')

    wd.get('http://127.0.0.1/mgr/sign.html')

    # 根据 ID 选择元素，并且输入字符串
    wd.find_element_by_id('username').send_keys('byhy')
    wd.find_element_by_id('password').send_keys('88888888')

    # 根据标签名查找元素
    wd.find_element_by_tag_name('button').click()

def clickMenu(wd,menuName):
    if menuName == '客户':
        # 找到所有的菜单
        menus = wd.find_elements_by_css_selector('.sidebar-menu span')

        # 第一个span对应的菜单是 客户，点击它
        menus[0].click()


    if menuName == '药品':
        # 找到所有的菜单
        menus = wd.find_elements_by_css_selector('.sidebar-menu span')

        # 第2个span对应的菜单是 药品，点击它
        menus[1].click()



#  删除界面列出的所有条目，
#  比如： 订单，或者客户，或者药品
#  由于 代码逻辑相同，封装在函数 delAll 中
def delAll(wd):

    while True:
        # 修改全局等待时间，以免找不到元素，等待时间较长
        wd.implicitly_wait(1)
        # 找到所有删除按钮
        # 注意，一定要每次循环都 执行一遍，
        # 因为每次删除后，界面元素重新 产生了
        delButtons = wd.find_elements_by_css_selector(
            '.search-result-item-actionbar label:nth-last-child(1)')

        # 再改回原来的等待时间
        wd.implicitly_wait(5)

        # 没有删除按钮，说明已经全部删除了
        if not delButtons:
            break

        # 点击删除按钮
        delButtons[0].click()

        # 弹出对话框 点击确定
        wd.switch_to.alert.accept()

        # 等待1秒，等界面刷新
        time.sleep(1)



#  添加 客户 或者 药品
#  由于 代码逻辑相同，封装在函数中
def addCustomerOrMedicion(wd,field1,field2,field3):
    # 点击添加按钮
    wd.find_element_by_class_name('glyphicon-plus').click()

    # form-contorl 对应3个输入框
    inputs = wd.find_elements_by_css_selector('.add-one-area .form-control')

    # 输入 药品名称
    inputs[0].send_keys(field1)
    # 输入 编号
    inputs[1].send_keys(field2)
    # 输入 描述
    inputs[2].send_keys(field3)

    # 第1个 btn-xs 就是创建按钮， 点击创建按钮
    wd.find_element_by_css_selector('.add-one-area .btn-xs').click()

    # 等待界面刷新稳定
    time.sleep(1)