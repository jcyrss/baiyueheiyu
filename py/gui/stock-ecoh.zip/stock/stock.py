from PySide2.QtWidgets import QApplication
from PySide2.QtUiTools import QUiLoader
import pyqtgraph as pg
import re,os,json,requests,threading,PySide2

class Stock:

    def __init__(self):

        self.stocklist = ''
        if os.path.exists('stock.txt'):
            with open('stock.txt',encoding='utf8') as f:
                self.stocklist = f.read()

        self.curStockHistoryData = {}
        self.curStockRealTimeData = {}

        loader = QUiLoader()

        # pyside2 一定要 使用registerCustomWidget
        # 来 注册 ui文件中的第三方控件，
        loader.registerCustomWidget(pg.PlotWidget)
        self.ui = loader.load("main.ui")

        self.ui.setWindowTitle('白月黑羽股票分析')

        self.ui.historyPlot.showGrid(x=True, y=True)

        self.ui.updateStockListButton.clicked.connect(self.updateStock)
        self.ui.stockNameEdit.textChanged.connect(self.inputStockName)
        self.ui.getHistoryInfoButton.clicked.connect(self.pullHistoryInfo)

        # 鼠标在股票历史图上移动时，获取鼠标信息，进行处理
        self.ui.historyPlot.scene().sigMouseMoved.connect(self.mouseMovedOnHistory)
        self.curveHistory = self.ui.historyPlot.getPlotItem().plot()



    def mouseMovedOnHistory(self,pos):
        if not self.curStockHistoryData:
            return
        # pos 参数是像素坐标，需要转化为刻度坐标
        act_pos = self.curveHistory.mapFromScene(pos)
        if type(act_pos) != PySide2.QtCore.QPointF:
            return
        x = int(act_pos.x())
        y = act_pos.y()
        if x in self.curStockHistoryData:
            self.ui.statusbar.showMessage(f'坐标: ({x}, {y:.2f})   历史股价: {self.curStockHistoryData[x]}')


    def pullHistoryInfo(self):
        self.ui.statusbar.showMessage('')

        stock = self.ui.stockListBox.currentText()
        if not stock:
            self.ui.statusbar.showMessage('你必须先选择一支股票！！')
            return

        code = stock.split('(')[1][:-1]

        # 先清除原来保存的数据，再存入新的数据
        self.curStockHistoryData.clear()
        self.ui.historyInfoBrowser.clear()
        self.ui.historyPlot.clear()

        startDate = self.ui.startDateEdit.date().toString('yyyyMMdd')
        endDate = self.ui.endDateEdit.date().toString('yyyyMMdd')

        # 搜狐的历史股票信息参考
        # https://blog.csdn.net/leijia_xing/article/details/81139005
        url = f'http://q.stock.sohu.com/hisHq?code=cn_{code}&start={startDate}&end={endDate}&stat=1&order=A'
        retStr = requests.get(url).text

        self.ui.historyInfoBrowser.setPlainText(retStr)

        #   作图
        historyData = json.loads(retStr)[0]['hq']

        closePriceList = []
        xpos = 0
        for dayInfo in historyData:
            # dateList.append((xpos,dayInfo[0]))
            # 获取收盘价
            closePriceList.append(float(dayInfo[2]))

            self.curStockHistoryData[xpos] = f'{dayInfo[0]} = {dayInfo[2]}'
            xpos += 1

        # xax = self.ui.historyPlot.getAxis('bottom')
        # xax.setTicks([dateList])
        # xax.setTickSpacing(100,10)

        # 通过控件名称 historyPlot，找到Qt designer设计的 控件
        self.ui.historyPlot.plot(closePriceList)

        # 每次重新作图，plot item 都会更新
        self.curveHistory = self.ui.historyPlot.getPlotItem().plot()


    # 每次stockListBox框中的信息，都会传入到这个方法
    def inputStockName(self,name):
        self.ui.stockListBox.clear()

        name = name.strip()
        if not name:
            return

        # 如果是数字，一定要写全股票代码
        if name.isdigit():
            if len(name)<6:
                return

        pattern = f'^.*{name}.*$'

        # 否则进行搜索匹配，最多只显示50个
        ret = re.findall(pattern,self.stocklist,re.M)[:50]
        # print(ret)

        self.ui.stockListBox.addItems(ret)

    def updateStock(self):
        # 在新线程中运行，防止阻塞主线程
        def threadUpdateStock():
            stocklist = ''
            self.ui.statusbar.showMessage('正在更新信息，请稍等...')

            res = requests.get('http://quote.eastmoney.com/stock_list.html')

            # 获取HTML内容字符串
            info = res.content.decode('gbk')

            # 使用正则表达式匹配
            pattern = '<li><a target=\"_blank\" href=\"http://quote\.eastmoney\.com/.+html\">(.*)</a>'
            stocks = re.findall(pattern, info)

            with open('stock.txt', 'w', encoding='utf8') as f:
                for stock in stocks:
                    stocklist += f'{stock}\n'
                    f.write(f'{stock}\n')

            self.stocklist = stocklist
            self.ui.statusbar.showMessage('更新股票信息成功')

        thread = threading.Thread(target=threadUpdateStock)
        thread.start()

app = QApplication([])
stock = Stock()
stock.ui.show()
app.exec_()